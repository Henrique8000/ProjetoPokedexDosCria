//
//  ProjectPokeApp.swift
//  ProjectPoke
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

@main
struct ProjectPokeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
