//
//  StatsView.swift
//  Pokedex
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

struct StatsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct StatsView_Previews: PreviewProvider {
    static var previews: some View {
        StatsView()
    }
}
