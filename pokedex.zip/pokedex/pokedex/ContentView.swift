//
//  ContentView.swift
//  pokedex
//
//  Created by Aluno Mack on 20/03/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Text("Pokédex")
                .font(.title)
            TabView {
                
                PokedexView()
                    .tabItem {
                        Label("Pokédex", systemImage: "book")
                    }
                
                StatsView()
                    .tabItem{
                        Label("Estatísticas", systemImage: "chart.bar.xaxis")
                    }
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
