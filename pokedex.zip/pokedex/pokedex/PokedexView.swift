//
//  PokedexView.swift
//  Pokedex
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

struct PokedexView: View {
    @State var pesquisa : String = ""
    @State var input : String = ""
    
    var body: some View {
        VStack {
            TextField("Pesquisar Pokémon", text: $pesquisa)
                .padding(10)
                .textFieldStyle(.roundedBorder)
            List{
                ForEach(pokemons, id: \.self) { item in
                    if pesquisa != ""{
                        
                        
                        
                    }
                    else{
                        HStack{
                            Circle()
                                .fill(.red)
                                .frame(width: 50)
                            NavigationLink("\(item.id) \(item.name)".capitalized,
                                           destination: Text("Detalhes do \(item.name)"))

                            
                        }
                    }
                }
            }
        }
    }
    
}

struct PokedexView_Previews: PreviewProvider {
    static var previews: some View {
        PokedexView()
    }
}
