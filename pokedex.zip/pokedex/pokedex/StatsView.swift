//
//  StatsView.swift
//  Pokedex
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

struct StatsView: View {
    var body: some View {
        HStack{
            Text("Você possui: \(havePoke.count)/\(pokemons.count) Pokémons")
        }
    } 
}

struct StatsView_Previews: PreviewProvider {
    static var previews: some View {
        StatsView()
    }
}
