//
//  PokedexApp.swift
//  Pokedex
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

@main
struct PokedexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
